import { Link } from "react-router";
import { ArrowRight, Zap, Shield, TrendingUp, Users, Bike, Search, Filter } from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { motion } from "motion/react";

const featuredBikes = [
  {
    id: 1,
    name: "Royal Enfield Classic 350",
    price: "₹1,85,000",
    year: 2023,
    km: "8,500 km",
    location: "Kochi",
    image: "https://images.unsplash.com/photo-1663543454316-b5f8917b0278?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyb3lhbCUyMGVuZmllbGQlMjBjbGFzc2ljJTIwbW90b3JjeWNsZXxlbnwxfHx8fDE3NzE4Mzg3NzN8MA&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    id: 2,
    name: "Yamaha R15 V4",
    price: "₹1,45,000",
    year: 2024,
    km: "3,200 km",
    location: "Trivandrum",
    image: "https://images.unsplash.com/photo-1709133650353-dcbabe8015ee?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5YW1haGElMjByMTUlMjBzcG9ydCUyMGJpa2V8ZW58MXx8fHwxNzcxODM4NzczfDA&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    id: 3,
    name: "KTM Duke 390",
    price: "₹2,20,000",
    year: 2023,
    km: "5,800 km",
    location: "Calicut",
    image: "https://images.unsplash.com/photo-1670012300918-6e0dda76af1a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxrdG0lMjBkdWtlJTIwbW90b3JjeWNsZXxlbnwxfHx8fDE3NzE4MzQwNDJ8MA&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    id: 4,
    name: "Kawasaki Ninja 300",
    price: "₹2,85,000",
    year: 2024,
    km: "2,100 km",
    location: "Thrissur",
    image: "https://images.unsplash.com/photo-1736839659107-1befef3f3207?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxrYXdhc2FraSUyMG5pbmphJTIwc3BvcnQlMjBiaWtlfGVufDF8fHx8MTc3MTgyMDgyNnww&ixlib=rb-4.1.0&q=80&w=1080",
  },
];

const categories = [
  { name: "Sport Bikes", count: "245+", color: "from-[var(--electric-blue)] to-[var(--neon-cyan)]" },
  { name: "Cruisers", count: "189+", color: "from-[var(--flame-orange)] to-[var(--hot-pink)]" },
  { name: "Adventure", count: "156+", color: "from-[var(--lime-pulse)] to-[var(--neon-cyan)]" },
  { name: "Commuters", count: "432+", color: "from-[var(--neon-cyan)] to-[var(--electric-blue)]" },
];

const stats = [
  { icon: Bike, label: "Active Listings", value: "1,200+" },
  { icon: Users, label: "Happy Riders", value: "5,000+" },
  { icon: TrendingUp, label: "Successful Deals", value: "850+" },
  { icon: Shield, label: "Verified Sellers", value: "95%" },
];

export function Home() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center overflow-hidden">
        {/* Background Image */}
        <div className="absolute inset-0">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1756919071517-9850563d788c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzcG9ydCUyMG1vdG9yY3ljbGUlMjByaWRlciUyMGhpZ2h3YXl8ZW58MXx8fHwxNzcxODM4NzcyfDA&ixlib=rb-4.1.0&q=80&w=1080"
            alt="Hero background"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[var(--midnight-black)] via-[var(--midnight-black)]/80 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-t from-[var(--midnight-black)] via-transparent to-transparent" />
        </div>

        {/* Content */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-3xl"
          >
            <div className="inline-block px-4 py-2 bg-white/5 backdrop-blur-md border border-white/10 rounded-full mb-6">
              <span className="text-[var(--neon-cyan)]">🔥 Kerala's #1 Bike Marketplace</span>
            </div>
            
            <h1 className="text-5xl md:text-7xl mb-6 leading-tight">
              <span className="bg-gradient-to-r from-white via-white to-white/80 bg-clip-text text-transparent">
                Ride. Trade.
              </span>
              <br />
              <span className="bg-gradient-to-r from-[var(--electric-blue)] via-[var(--neon-cyan)] to-[var(--lime-pulse)] bg-clip-text text-transparent">
                Connect.
              </span>
            </h1>
            
            <p className="text-xl text-white/70 mb-8 max-w-2xl">
              The complete motorcycle ecosystem. Buy, sell, and connect with Kerala's largest biker community.
            </p>

            {/* Search Bar */}
            <div className="flex flex-col sm:flex-row gap-3 mb-8">
              <div className="flex-1 flex gap-2 p-2 bg-white/5 backdrop-blur-xl border border-white/10 rounded-xl">
                <Search className="w-5 h-5 text-white/40 ml-2 mt-2.5" />
                <Input
                  placeholder="Search bikes, brands, models..."
                  className="flex-1 bg-transparent border-none text-white placeholder:text-white/40"
                />
                <Button className="bg-gradient-to-r from-[var(--electric-blue)] to-[var(--neon-cyan)] hover:opacity-90 shrink-0">
                  <Filter className="w-4 h-4 mr-2" />
                  Search
                </Button>
              </div>
            </div>

            <div className="flex flex-wrap gap-4">
              <Link to="/marketplace">
                <Button size="lg" className="bg-gradient-to-r from-[var(--electric-blue)] to-[var(--neon-cyan)] hover:opacity-90 shadow-2xl shadow-[var(--electric-blue)]/30">
                  Browse Marketplace
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
              <Link to="/sell">
                <Button size="lg" variant="outline" className="border-white/20 text-white hover:bg-white/10">
                  Sell Your Bike
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>

        {/* Floating Elements */}
        <div className="absolute top-20 right-20 w-64 h-64 bg-[var(--electric-blue)] rounded-full blur-[100px] opacity-20 animate-pulse" />
        <div className="absolute bottom-20 right-40 w-96 h-96 bg-[var(--neon-cyan)] rounded-full blur-[120px] opacity-10" />
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-gradient-to-b from-[var(--midnight-black)] to-[var(--dark-surface)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="text-center group"
              >
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-r from-[var(--electric-blue)] to-[var(--neon-cyan)] mb-4 group-hover:scale-110 transition-transform shadow-lg shadow-[var(--electric-blue)]/30">
                  <stat.icon className="w-8 h-8 text-white" />
                </div>
                <div className="text-3xl bg-gradient-to-r from-white to-white/80 bg-clip-text text-transparent mb-2">
                  {stat.value}
                </div>
                <div className="text-white/60">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-20 bg-[var(--dark-surface)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl mb-4">
              <span className="bg-gradient-to-r from-white to-white/80 bg-clip-text text-transparent">
                Browse by Category
              </span>
            </h2>
            <p className="text-white/60 text-lg">Find your perfect ride</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {categories.map((category, index) => (
              <motion.div
                key={category.name}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Link to="/marketplace" className="block group">
                  <div className="relative p-8 rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10 hover:border-white/20 transition-all overflow-hidden group-hover:shadow-2xl">
                    <div className={`absolute inset-0 bg-gradient-to-br ${category.color} opacity-0 group-hover:opacity-10 transition-opacity`} />
                    <div className="relative z-10">
                      <div className="text-2xl mb-2 text-white">{category.name}</div>
                      <div className="text-white/60">{category.count} bikes</div>
                    </div>
                    <Zap className="absolute -bottom-4 -right-4 w-24 h-24 text-white/5 group-hover:text-white/10 transition-colors" />
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Bikes */}
      <section className="py-20 bg-gradient-to-b from-[var(--dark-surface)] to-[var(--midnight-black)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-12">
            <div>
              <h2 className="text-4xl mb-4">
                <span className="bg-gradient-to-r from-white to-white/80 bg-clip-text text-transparent">
                  Featured Bikes
                </span>
              </h2>
              <p className="text-white/60 text-lg">Handpicked premium listings</p>
            </div>
            <Link to="/marketplace">
              <Button variant="outline" className="border-white/20 text-white hover:bg-white/10">
                View All
                <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredBikes.map((bike, index) => (
              <motion.div
                key={bike.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Link to={`/marketplace/${bike.id}`} className="block group">
                  <div className="rounded-2xl overflow-hidden bg-[var(--dark-card)] border border-white/10 hover:border-[var(--electric-blue)] transition-all hover:shadow-2xl hover:shadow-[var(--electric-blue)]/20">
                    <div className="relative aspect-[4/3] overflow-hidden">
                      <ImageWithFallback
                        src={bike.image}
                        alt={bike.name}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                      <div className="absolute top-3 right-3 px-3 py-1 bg-[var(--electric-blue)] rounded-full text-white text-sm">
                        Featured
                      </div>
                    </div>
                    <div className="p-5">
                      <h3 className="text-lg text-white mb-2 group-hover:text-[var(--neon-cyan)] transition-colors">
                        {bike.name}
                      </h3>
                      <div className="flex items-center gap-4 text-sm text-white/60 mb-3">
                        <span>{bike.year}</span>
                        <span>•</span>
                        <span>{bike.km}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-xl text-[var(--neon-cyan)]">{bike.price}</span>
                        <span className="text-sm text-white/60">{bike.location}</span>
                      </div>
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-[var(--midnight-black)] relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-[var(--electric-blue)]/10 via-[var(--neon-cyan)]/10 to-[var(--flame-orange)]/10" />
        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl mb-6">
              <span className="bg-gradient-to-r from-white to-white/80 bg-clip-text text-transparent">
                Ready to Sell Your Bike?
              </span>
            </h2>
            <p className="text-xl text-white/70 mb-8">
              Get the best price with our AI-powered price estimator and reach thousands of verified buyers.
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Link to="/price-estimator">
                <Button size="lg" className="bg-gradient-to-r from-[var(--electric-blue)] to-[var(--neon-cyan)] hover:opacity-90 shadow-2xl shadow-[var(--electric-blue)]/30">
                  Try Price Estimator
                  <Zap className="ml-2 w-5 h-5" />
                </Button>
              </Link>
              <Link to="/sell">
                <Button size="lg" variant="outline" className="border-white/20 text-white hover:bg-white/10">
                  List Your Bike
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
