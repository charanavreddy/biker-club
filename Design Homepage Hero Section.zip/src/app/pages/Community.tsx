import { Heart, MessageCircle, Share2, TrendingUp, Users, Plus, Image as ImageIcon } from "lucide-react";
import { Button } from "../components/ui/button";
import { Textarea } from "../components/ui/textarea";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { motion } from "motion/react";

const posts = [
  {
    id: 1,
    author: "Arjun Nair",
    avatar: "AN",
    time: "2 hours ago",
    content: "Just completed an epic 500km ride through the Western Ghats! The roads were absolutely stunning. Royal Enfield Classic performed like a dream. Anyone else planning rides this weekend? 🏍️",
    image: "https://images.unsplash.com/photo-1714015936958-a3a52daa9705?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiaWtlciUyMGdyb3VwJTIwcmlkaW5nJTIwbW90b3JjeWNsZXN8ZW58MXx8fHwxNzcxODM4OTQ3fDA&ixlib=rb-4.1.0&q=80&w=1080",
    likes: 45,
    comments: 12,
    trending: true,
  },
  {
    id: 2,
    author: "Priya Menon",
    avatar: "PM",
    time: "5 hours ago",
    content: "New helmet arrived! Safety first, style always. 🪖 What's your go-to brand for riding gear?",
    image: "https://images.unsplash.com/photo-1767274859534-03d9f745030d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb3RvcmN5Y2xlJTIwaGVsbWV0JTIwZ2VhcnxlbnwxfHx8fDE3NzE3Njk1Mjh8MA&ixlib=rb-4.1.0&q=80&w=1080",
    likes: 32,
    comments: 8,
    trending: false,
  },
  {
    id: 3,
    author: "Karthik Krishnan",
    avatar: "KK",
    time: "1 day ago",
    content: "DIY maintenance day! Changed my bike's oil and cleaned the chain. Feels so satisfying to take care of your own ride. Drop your maintenance tips below! 🔧",
    image: "https://images.unsplash.com/photo-1762604462279-dc3216efe59b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb3RvcmN5Y2xlJTIwbWFpbnRlbmFuY2UlMjB0b29sc3xlbnwxfHx8fDE3NzE4Mzg5NDd8MA&ixlib=rb-4.1.0&q=80&w=1080",
    likes: 58,
    comments: 15,
    trending: true,
  },
];

const trendingTopics = [
  { tag: "WesternGhatsRide", posts: 234 },
  { tag: "BikeMaintenanceTips", posts: 189 },
  { tag: "SafetyGear", posts: 156 },
  { tag: "KeralaRiders", posts: 432 },
];

export function Community() {
  return (
    <div className="min-h-screen bg-[var(--midnight-black)] py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Feed */}
          <div className="lg:col-span-2 space-y-6">
            {/* Create Post */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="rounded-2xl p-6 bg-[var(--dark-card)] border border-white/10"
            >
              <h2 className="text-xl text-white mb-4">Share with the community</h2>
              <Textarea
                placeholder="What's on your mind, rider?"
                className="bg-white/5 border-white/10 text-white placeholder:text-white/40 mb-3"
                rows={3}
              />
              <div className="flex items-center justify-between">
                <Button variant="ghost" size="sm" className="text-white/60 hover:text-white hover:bg-white/10">
                  <ImageIcon className="w-4 h-4 mr-2" />
                  Add Photo
                </Button>
                <Button className="bg-gradient-to-r from-[var(--electric-blue)] to-[var(--neon-cyan)] hover:opacity-90">
                  <Plus className="w-4 h-4 mr-2" />
                  Post
                </Button>
              </div>
            </motion.div>

            {/* Posts */}
            {posts.map((post, index) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="rounded-2xl p-6 bg-[var(--dark-card)] border border-white/10 hover:border-white/20 transition-colors"
              >
                {/* Post Header */}
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-r from-[var(--electric-blue)] to-[var(--neon-cyan)] flex items-center justify-center text-white">
                    {post.avatar}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="text-white">{post.author}</h3>
                      {post.trending && (
                        <span className="px-2 py-0.5 bg-[var(--flame-orange)]/20 text-[var(--flame-orange)] text-xs rounded-full flex items-center gap-1">
                          <TrendingUp className="w-3 h-3" />
                          Trending
                        </span>
                      )}
                    </div>
                    <p className="text-white/60 text-sm">{post.time}</p>
                  </div>
                </div>

                {/* Post Content */}
                <p className="text-white/90 mb-4">{post.content}</p>

                {/* Post Image */}
                {post.image && (
                  <div className="rounded-xl overflow-hidden mb-4">
                    <ImageWithFallback
                      src={post.image}
                      alt="Post image"
                      className="w-full h-80 object-cover"
                    />
                  </div>
                )}

                {/* Post Actions */}
                <div className="flex items-center gap-6 pt-4 border-t border-white/10">
                  <button className="flex items-center gap-2 text-white/60 hover:text-[var(--hot-pink)] transition-colors group">
                    <Heart className="w-5 h-5 group-hover:fill-[var(--hot-pink)]" />
                    <span>{post.likes}</span>
                  </button>
                  <button className="flex items-center gap-2 text-white/60 hover:text-[var(--neon-cyan)] transition-colors">
                    <MessageCircle className="w-5 h-5" />
                    <span>{post.comments}</span>
                  </button>
                  <button className="flex items-center gap-2 text-white/60 hover:text-white transition-colors ml-auto">
                    <Share2 className="w-5 h-5" />
                  </button>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Community Stats */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="sticky top-24 rounded-2xl p-6 bg-gradient-to-br from-[var(--dark-card)] to-[var(--dark-surface)] border border-white/10"
            >
              <h3 className="text-white mb-4 flex items-center gap-2">
                <Users className="w-5 h-5 text-[var(--neon-cyan)]" />
                Community Stats
              </h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-white/60">Active Members</span>
                  <span className="text-[var(--neon-cyan)]">5,234</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-white/60">Posts Today</span>
                  <span className="text-[var(--neon-cyan)]">156</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-white/60">Active Now</span>
                  <span className="text-[var(--lime-pulse)]">89</span>
                </div>
              </div>
            </motion.div>

            {/* Trending Topics */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
              className="rounded-2xl p-6 bg-[var(--dark-card)] border border-white/10"
            >
              <h3 className="text-white mb-4 flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-[var(--flame-orange)]" />
                Trending Topics
              </h3>
              <div className="space-y-3">
                {trendingTopics.map((topic, index) => (
                  <button
                    key={topic.tag}
                    className="w-full flex items-center justify-between p-3 rounded-lg bg-white/5 hover:bg-white/10 transition-colors group"
                  >
                    <span className="text-white group-hover:text-[var(--neon-cyan)] transition-colors">
                      #{topic.tag}
                    </span>
                    <span className="text-white/60 text-sm">{topic.posts} posts</span>
                  </button>
                ))}
              </div>
            </motion.div>

            {/* Join Groups */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="rounded-2xl p-6 bg-[var(--dark-card)] border border-white/10"
            >
              <h3 className="text-white mb-4">Suggested Groups</h3>
              <div className="space-y-3">
                {["Kerala Touring Club", "Royal Enfield Lovers", "Sport Bike Enthusiasts"].map((group) => (
                  <div key={group} className="flex items-center justify-between">
                    <span className="text-white/90">{group}</span>
                    <Button size="sm" variant="ghost" className="text-[var(--neon-cyan)] hover:bg-white/10">
                      Join
                    </Button>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
