import { useState } from "react";
import { Upload, Camera, Plus, X } from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { motion } from "motion/react";

export function SellBike() {
  const [uploadedImages, setUploadedImages] = useState<number>(0);

  return (
    <div className="min-h-screen bg-[var(--midnight-black)] py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-5xl mb-4">
            <span className="bg-gradient-to-r from-white to-white/80 bg-clip-text text-transparent">
              List Your Bike
            </span>
          </h1>
          <p className="text-xl text-white/60">
            Reach thousands of verified buyers in minutes
          </p>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-2xl p-8 bg-[var(--dark-card)] border border-white/10"
        >
          <form className="space-y-8">
            {/* Basic Details */}
            <section>
              <h2 className="text-2xl text-white mb-6">Basic Details</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label className="text-white mb-2 block">Brand *</Label>
                  <Select>
                    <SelectTrigger className="bg-white/5 border-white/10 text-white">
                      <SelectValue placeholder="Select brand" />
                    </SelectTrigger>
                    <SelectContent className="bg-[var(--dark-surface)] border-white/10">
                      <SelectItem value="royal-enfield">Royal Enfield</SelectItem>
                      <SelectItem value="yamaha">Yamaha</SelectItem>
                      <SelectItem value="ktm">KTM</SelectItem>
                      <SelectItem value="honda">Honda</SelectItem>
                      <SelectItem value="kawasaki">Kawasaki</SelectItem>
                      <SelectItem value="bajaj">Bajaj</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-white mb-2 block">Model *</Label>
                  <Input
                    placeholder="e.g., Classic 350"
                    className="bg-white/5 border-white/10 text-white placeholder:text-white/40"
                  />
                </div>

                <div>
                  <Label className="text-white mb-2 block">Year *</Label>
                  <Select>
                    <SelectTrigger className="bg-white/5 border-white/10 text-white">
                      <SelectValue placeholder="Select year" />
                    </SelectTrigger>
                    <SelectContent className="bg-[var(--dark-surface)] border-white/10">
                      <SelectItem value="2024">2024</SelectItem>
                      <SelectItem value="2023">2023</SelectItem>
                      <SelectItem value="2022">2022</SelectItem>
                      <SelectItem value="2021">2021</SelectItem>
                      <SelectItem value="2020">2020</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-white mb-2 block">Kilometers *</Label>
                  <Input
                    type="number"
                    placeholder="e.g., 8500"
                    className="bg-white/5 border-white/10 text-white placeholder:text-white/40"
                  />
                </div>

                <div>
                  <Label className="text-white mb-2 block">Price (₹) *</Label>
                  <Input
                    type="number"
                    placeholder="e.g., 185000"
                    className="bg-white/5 border-white/10 text-white placeholder:text-white/40"
                  />
                </div>

                <div>
                  <Label className="text-white mb-2 block">Location *</Label>
                  <Select>
                    <SelectTrigger className="bg-white/5 border-white/10 text-white">
                      <SelectValue placeholder="Select location" />
                    </SelectTrigger>
                    <SelectContent className="bg-[var(--dark-surface)] border-white/10">
                      <SelectItem value="kochi">Kochi</SelectItem>
                      <SelectItem value="trivandrum">Trivandrum</SelectItem>
                      <SelectItem value="calicut">Calicut</SelectItem>
                      <SelectItem value="thrissur">Thrissur</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </section>

            {/* Specifications */}
            <section className="border-t border-white/10 pt-8">
              <h2 className="text-2xl text-white mb-6">Specifications</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label className="text-white mb-2 block">Fuel Type</Label>
                  <Select>
                    <SelectTrigger className="bg-white/5 border-white/10 text-white">
                      <SelectValue placeholder="Select fuel type" />
                    </SelectTrigger>
                    <SelectContent className="bg-[var(--dark-surface)] border-white/10">
                      <SelectItem value="petrol">Petrol</SelectItem>
                      <SelectItem value="diesel">Diesel</SelectItem>
                      <SelectItem value="electric">Electric</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-white mb-2 block">Number of Owners</Label>
                  <Select>
                    <SelectTrigger className="bg-white/5 border-white/10 text-white">
                      <SelectValue placeholder="Select owners" />
                    </SelectTrigger>
                    <SelectContent className="bg-[var(--dark-surface)] border-white/10">
                      <SelectItem value="1">1st Owner</SelectItem>
                      <SelectItem value="2">2nd Owner</SelectItem>
                      <SelectItem value="3">3rd Owner</SelectItem>
                      <SelectItem value="4+">4+ Owners</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-white mb-2 block">Engine Capacity (cc)</Label>
                  <Input
                    placeholder="e.g., 350"
                    className="bg-white/5 border-white/10 text-white placeholder:text-white/40"
                  />
                </div>

                <div>
                  <Label className="text-white mb-2 block">Condition</Label>
                  <Select>
                    <SelectTrigger className="bg-white/5 border-white/10 text-white">
                      <SelectValue placeholder="Select condition" />
                    </SelectTrigger>
                    <SelectContent className="bg-[var(--dark-surface)] border-white/10">
                      <SelectItem value="excellent">Excellent</SelectItem>
                      <SelectItem value="good">Good</SelectItem>
                      <SelectItem value="fair">Fair</SelectItem>
                      <SelectItem value="poor">Poor</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </section>

            {/* Description */}
            <section className="border-t border-white/10 pt-8">
              <h2 className="text-2xl text-white mb-6">Description</h2>
              <div>
                <Label className="text-white mb-2 block">Tell buyers about your bike *</Label>
                <Textarea
                  placeholder="Describe the condition, any modifications, service history, reason for selling, etc."
                  className="bg-white/5 border-white/10 text-white placeholder:text-white/40 min-h-[150px]"
                />
                <p className="text-white/60 text-sm mt-2">
                  Detailed descriptions get 3x more inquiries
                </p>
              </div>
            </section>

            {/* Photos */}
            <section className="border-t border-white/10 pt-8">
              <h2 className="text-2xl text-white mb-2">Photos</h2>
              <p className="text-white/60 mb-6">Add at least 3 photos (max 10)</p>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {/* Upload Boxes */}
                {[...Array(Math.min(4, 10 - uploadedImages))].map((_, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => setUploadedImages(uploadedImages + 1)}
                    className="aspect-square rounded-xl border-2 border-dashed border-white/20 hover:border-[var(--electric-blue)] bg-white/5 hover:bg-white/10 flex flex-col items-center justify-center gap-2 transition-all group"
                  >
                    {i === 0 ? (
                      <>
                        <Camera className="w-8 h-8 text-white/40 group-hover:text-[var(--electric-blue)]" />
                        <span className="text-white/60 text-sm">Main Photo</span>
                      </>
                    ) : (
                      <>
                        <Plus className="w-8 h-8 text-white/40 group-hover:text-[var(--electric-blue)]" />
                        <span className="text-white/60 text-sm">Add Photo</span>
                      </>
                    )}
                  </button>
                ))}

                {/* Uploaded Images Preview */}
                {[...Array(uploadedImages)].map((_, i) => (
                  <div key={`uploaded-${i}`} className="aspect-square rounded-xl bg-white/10 relative group">
                    <button
                      type="button"
                      onClick={() => setUploadedImages(uploadedImages - 1)}
                      className="absolute top-2 right-2 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X className="w-4 h-4 text-white" />
                    </button>
                    <div className="w-full h-full flex items-center justify-center text-white/60">
                      Photo {i + 1}
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* Contact Information */}
            <section className="border-t border-white/10 pt-8">
              <h2 className="text-2xl text-white mb-6">Contact Information</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label className="text-white mb-2 block">Name *</Label>
                  <Input
                    placeholder="Your full name"
                    className="bg-white/5 border-white/10 text-white placeholder:text-white/40"
                  />
                </div>

                <div>
                  <Label className="text-white mb-2 block">Phone Number *</Label>
                  <Input
                    type="tel"
                    placeholder="+91 1234567890"
                    className="bg-white/5 border-white/10 text-white placeholder:text-white/40"
                  />
                </div>
              </div>
            </section>

            {/* Submit */}
            <div className="flex gap-4 pt-6">
              <Button
                type="submit"
                className="flex-1 bg-gradient-to-r from-[var(--electric-blue)] to-[var(--neon-cyan)] hover:opacity-90 shadow-xl shadow-[var(--electric-blue)]/30"
              >
                <Upload className="w-5 h-5 mr-2" />
                Publish Listing
              </Button>
              <Button type="button" variant="outline" className="border-white/20 text-white hover:bg-white/10">
                Save as Draft
              </Button>
            </div>
          </form>
        </motion.div>
      </div>
    </div>
  );
}
