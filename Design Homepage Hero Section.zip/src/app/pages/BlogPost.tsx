import { useParams, Link } from "react-router";
import { ArrowLeft, Calendar, User, Clock, Share2, Heart } from "lucide-react";
import { Button } from "../components/ui/button";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";

export function BlogPost() {
  const { id } = useParams();

  return (
    <div className="min-h-screen bg-[var(--midnight-black)] py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <Link to="/blog" className="inline-flex items-center gap-2 text-white/70 hover:text-[var(--neon-cyan)] transition-colors mb-6">
          <ArrowLeft className="w-5 h-5" />
          Back to Blog
        </Link>

        <article>
          {/* Header */}
          <header className="mb-8">
            <div className="inline-block px-3 py-1 bg-[var(--electric-blue)]/20 text-[var(--electric-blue)] rounded-full text-sm mb-4">
              Travel
            </div>
            <h1 className="text-4xl md:text-5xl text-white mb-4">
              Top 10 Scenic Bike Routes in Kerala
            </h1>
            <div className="flex items-center gap-6 text-white/60 mb-6">
              <span className="flex items-center gap-2">
                <User className="w-5 h-5" />
                Arun Kumar
              </span>
              <span className="flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                Feb 20, 2026
              </span>
              <span className="flex items-center gap-2">
                <Clock className="w-5 h-5" />
                5 min read
              </span>
            </div>
            <div className="flex gap-3">
              <Button variant="outline" size="sm" className="border-white/20 text-white hover:bg-white/10">
                <Heart className="w-4 h-4 mr-2" />
                Save
              </Button>
              <Button variant="outline" size="sm" className="border-white/20 text-white hover:bg-white/10">
                <Share2 className="w-4 h-4 mr-2" />
                Share
              </Button>
            </div>
          </header>

          {/* Featured Image */}
          <div className="rounded-2xl overflow-hidden mb-8">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1714015936958-a3a52daa9705?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiaWtlciUyMGdyb3VwJTIwcmlkaW5nJTIwbW90b3JjeWNsZXN8ZW58MXx8fHwxNzcxODM4OTQ3fDA&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Blog post"
              className="w-full h-96 object-cover"
            />
          </div>

          {/* Content */}
          <div className="prose prose-invert prose-lg max-w-none">
            <div className="text-white/80 leading-relaxed space-y-6">
              <p>
                Kerala, often called "God's Own Country," offers some of the most spectacular motorcycle routes in India. From winding mountain roads to coastal highways, the state provides endless opportunities for memorable rides.
              </p>
              <p>
                Whether you're a seasoned rider or just starting your journey, these routes will take your breath away. Here are our top 10 picks for the best scenic bike routes in Kerala.
              </p>
              <h2 className="text-2xl text-white mt-8 mb-4">1. Kochi to Munnar</h2>
              <p>
                This 130km route takes you from the coastal city of Kochi up into the Western Ghats, offering stunning views of tea plantations, waterfalls, and misty mountains. The best time to ride is early morning when the mist creates an ethereal atmosphere.
              </p>
              <h2 className="text-2xl text-white mt-8 mb-4">2. Wayanad Circuit</h2>
              <p>
                The Wayanad district offers multiple scenic routes through dense forests, wildlife sanctuaries, and spice plantations. The roads are well-maintained and perfect for both solo riders and group tours.
              </p>
              <h2 className="text-2xl text-white mt-8 mb-4">3. Coastal Highway (NH66)</h2>
              <p>
                Running along Kerala's entire coastline, this highway offers stunning ocean views, fishing villages, and beautiful beaches. Stop at Varkala or Kovalam for a refreshing break by the sea.
              </p>
            </div>
          </div>
        </article>
      </div>
    </div>
  );
}
