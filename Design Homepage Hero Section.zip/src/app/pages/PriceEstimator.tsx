import { useState } from "react";
import { Zap, TrendingUp, TrendingDown, Info } from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { motion } from "motion/react";

export function PriceEstimator() {
  const [estimatedPrice, setEstimatedPrice] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);

  const handleEstimate = () => {
    setLoading(true);
    // Simulate AI calculation
    setTimeout(() => {
      setEstimatedPrice(185000);
      setLoading(false);
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-[var(--midnight-black)] py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[var(--electric-blue)]/20 to-[var(--neon-cyan)]/20 border border-[var(--electric-blue)]/30 rounded-full mb-6">
            <Zap className="w-5 h-5 text-[var(--neon-cyan)]" />
            <span className="text-[var(--neon-cyan)]">AI-Powered Price Estimator</span>
          </div>
          <h1 className="text-5xl mb-4">
            <span className="bg-gradient-to-r from-white to-white/80 bg-clip-text text-transparent">
              Get Instant Price Estimate
            </span>
          </h1>
          <p className="text-xl text-white/60">
            Our AI analyzes market data to give you the most accurate price for your bike
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Form */}
          <div className="lg:col-span-2">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="rounded-2xl p-8 bg-[var(--dark-card)] border border-white/10"
            >
              <h2 className="text-2xl text-white mb-6">Bike Details</h2>
              
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label className="text-white mb-2 block">Brand</Label>
                    <Select>
                      <SelectTrigger className="bg-white/5 border-white/10 text-white">
                        <SelectValue placeholder="Select brand" />
                      </SelectTrigger>
                      <SelectContent className="bg-[var(--dark-surface)] border-white/10">
                        <SelectItem value="royal-enfield">Royal Enfield</SelectItem>
                        <SelectItem value="yamaha">Yamaha</SelectItem>
                        <SelectItem value="ktm">KTM</SelectItem>
                        <SelectItem value="honda">Honda</SelectItem>
                        <SelectItem value="kawasaki">Kawasaki</SelectItem>
                        <SelectItem value="bajaj">Bajaj</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label className="text-white mb-2 block">Model</Label>
                    <Input
                      placeholder="e.g., Classic 350"
                      className="bg-white/5 border-white/10 text-white placeholder:text-white/40"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label className="text-white mb-2 block">Year of Purchase</Label>
                    <Select>
                      <SelectTrigger className="bg-white/5 border-white/10 text-white">
                        <SelectValue placeholder="Select year" />
                      </SelectTrigger>
                      <SelectContent className="bg-[var(--dark-surface)] border-white/10">
                        <SelectItem value="2024">2024</SelectItem>
                        <SelectItem value="2023">2023</SelectItem>
                        <SelectItem value="2022">2022</SelectItem>
                        <SelectItem value="2021">2021</SelectItem>
                        <SelectItem value="2020">2020</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label className="text-white mb-2 block">Kilometers Driven</Label>
                    <Input
                      type="number"
                      placeholder="e.g., 8500"
                      className="bg-white/5 border-white/10 text-white placeholder:text-white/40"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label className="text-white mb-2 block">Condition</Label>
                    <Select>
                      <SelectTrigger className="bg-white/5 border-white/10 text-white">
                        <SelectValue placeholder="Select condition" />
                      </SelectTrigger>
                      <SelectContent className="bg-[var(--dark-surface)] border-white/10">
                        <SelectItem value="excellent">Excellent</SelectItem>
                        <SelectItem value="good">Good</SelectItem>
                        <SelectItem value="fair">Fair</SelectItem>
                        <SelectItem value="poor">Poor</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label className="text-white mb-2 block">Location</Label>
                    <Select>
                      <SelectTrigger className="bg-white/5 border-white/10 text-white">
                        <SelectValue placeholder="Select location" />
                      </SelectTrigger>
                      <SelectContent className="bg-[var(--dark-surface)] border-white/10">
                        <SelectItem value="kochi">Kochi</SelectItem>
                        <SelectItem value="trivandrum">Trivandrum</SelectItem>
                        <SelectItem value="calicut">Calicut</SelectItem>
                        <SelectItem value="thrissur">Thrissur</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label className="text-white mb-2 block">Number of Owners</Label>
                  <Select>
                    <SelectTrigger className="bg-white/5 border-white/10 text-white">
                      <SelectValue placeholder="Select owners" />
                    </SelectTrigger>
                    <SelectContent className="bg-[var(--dark-surface)] border-white/10">
                      <SelectItem value="1">1st Owner</SelectItem>
                      <SelectItem value="2">2nd Owner</SelectItem>
                      <SelectItem value="3">3rd Owner</SelectItem>
                      <SelectItem value="4+">4+ Owners</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button
                  onClick={handleEstimate}
                  disabled={loading}
                  className="w-full bg-gradient-to-r from-[var(--electric-blue)] to-[var(--neon-cyan)] hover:opacity-90 shadow-xl shadow-[var(--electric-blue)]/30"
                >
                  {loading ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2" />
                      Calculating...
                    </>
                  ) : (
                    <>
                      <Zap className="w-5 h-5 mr-2" />
                      Get AI Estimate
                    </>
                  )}
                </Button>
              </div>
            </motion.div>
          </div>

          {/* Result */}
          <div className="space-y-6">
            {estimatedPrice ? (
              <>
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                >
                  <Card className="bg-gradient-to-br from-[var(--electric-blue)]/20 to-[var(--neon-cyan)]/20 border-[var(--electric-blue)]/30">
                    <CardHeader>
                      <CardTitle className="text-white flex items-center gap-2">
                        <Zap className="w-5 h-5 text-[var(--neon-cyan)]" />
                        Estimated Price
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-4xl mb-4">
                        <span className="bg-gradient-to-r from-[var(--electric-blue)] to-[var(--neon-cyan)] bg-clip-text text-transparent">
                          ₹{(estimatedPrice / 1000).toFixed(0)}k
                        </span>
                      </div>
                      <div className="space-y-2 text-sm text-white/70">
                        <div className="flex items-center justify-between">
                          <span>Market Range</span>
                          <span className="text-white">₹170k - ₹200k</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span>Confidence</span>
                          <span className="text-[var(--lime-pulse)]">95%</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  <Card className="bg-[var(--dark-card)] border-white/10">
                    <CardHeader>
                      <CardTitle className="text-white text-sm">Market Insights</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="p-3 rounded-lg bg-white/5 flex items-start gap-3">
                        <TrendingUp className="w-5 h-5 text-[var(--lime-pulse)] shrink-0 mt-0.5" />
                        <div className="text-sm">
                          <div className="text-white mb-1">High Demand</div>
                          <div className="text-white/60">This model is trending +12% this month</div>
                        </div>
                      </div>
                      <div className="p-3 rounded-lg bg-white/5 flex items-start gap-3">
                        <TrendingDown className="w-5 h-5 text-[var(--flame-orange)] shrink-0 mt-0.5" />
                        <div className="text-sm">
                          <div className="text-white mb-1">Seasonal Factor</div>
                          <div className="text-white/60">Prices typically dip 5% in summer</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              </>
            ) : (
              <Card className="bg-[var(--dark-card)] border-white/10">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Info className="w-5 h-5 text-[var(--neon-cyan)]" />
                    How It Works
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm text-white/70">
                  <p>Our AI-powered estimator analyzes:</p>
                  <ul className="space-y-2">
                    <li className="flex items-start gap-2">
                      <span className="text-[var(--neon-cyan)]">•</span>
                      <span>Current market trends</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-[var(--neon-cyan)]">•</span>
                      <span>Similar bike sales</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-[var(--neon-cyan)]">•</span>
                      <span>Location-based demand</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-[var(--neon-cyan)]">•</span>
                      <span>Seasonal variations</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-[var(--neon-cyan)]">•</span>
                      <span>Bike condition & history</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
