import { Link } from "react-router";
import { Calendar, User, ArrowRight, TrendingUp } from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { motion } from "motion/react";

const blogPosts = [
  {
    id: 1,
    title: "Top 10 Scenic Bike Routes in Kerala",
    excerpt: "Discover the most breathtaking motorcycle routes through Kerala's stunning landscapes, from coastal highways to mountain passes.",
    author: "Arun Kumar",
    date: "Feb 20, 2026",
    readTime: "5 min read",
    category: "Travel",
    image: "https://images.unsplash.com/photo-1714015936958-a3a52daa9705?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiaWtlciUyMGdyb3VwJTIwcmlkaW5nJTIwbW90b3JjeWNsZXN8ZW58MXx8fHwxNzcxODM4OTQ3fDA&ixlib=rb-4.1.0&q=80&w=1080",
    trending: true,
  },
  {
    id: 2,
    title: "Essential Motorcycle Maintenance Guide",
    excerpt: "Keep your bike running smoothly with these expert maintenance tips. Learn when and how to service your motorcycle for optimal performance.",
    author: "Priya Menon",
    date: "Feb 18, 2026",
    readTime: "8 min read",
    category: "Maintenance",
    image: "https://images.unsplash.com/photo-1762604462279-dc3216efe59b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb3RvcmN5Y2xlJTIwbWFpbnRlbmFuY2UlMjB0b29sc3xlbnwxfHx8fDE3NzE4Mzg5NDd8MA&ixlib=rb-4.1.0&q=80&w=1080",
    trending: false,
  },
  {
    id: 3,
    title: "Choosing the Right Riding Gear",
    excerpt: "Safety meets style: A comprehensive guide to selecting the perfect helmet, jacket, gloves, and boots for your riding adventures.",
    author: "Karthik Krishnan",
    date: "Feb 15, 2026",
    readTime: "6 min read",
    category: "Safety",
    image: "https://images.unsplash.com/photo-1767274859534-03d9f745030d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb3RvcmN5Y2xlJTIwaGVsbWV0JTIwZ2VhcnxlbnwxfHx8fDE3NzE3Njk1Mjh8MA&ixlib=rb-4.1.0&q=80&w=1080",
    trending: true,
  },
];

const categories = ["All Posts", "Travel", "Maintenance", "Safety", "Reviews", "Community"];

export function Blog() {
  return (
    <div className="min-h-screen bg-[var(--midnight-black)] py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-5xl mb-4">
            <span className="bg-gradient-to-r from-white to-white/80 bg-clip-text text-transparent">
              Biker's Blog
            </span>
          </h1>
          <p className="text-xl text-white/60">Stories, tips, and insights from the road</p>
        </div>

        {/* Categories */}
        <div className="flex flex-wrap gap-3 justify-center mb-12">
          {categories.map((category) => (
            <button
              key={category}
              className={`px-4 py-2 rounded-full transition-all ${
                category === "All Posts"
                  ? "bg-gradient-to-r from-[var(--electric-blue)] to-[var(--neon-cyan)] text-white shadow-lg shadow-[var(--electric-blue)]/30"
                  : "bg-white/5 text-white/70 hover:bg-white/10 hover:text-white border border-white/10"
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Featured Post */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12"
        >
          <Link to={`/blog/${blogPosts[0].id}`} className="block group">
            <div className="rounded-2xl overflow-hidden bg-[var(--dark-card)] border border-white/10 hover:border-[var(--electric-blue)] transition-all">
              <div className="grid grid-cols-1 lg:grid-cols-2">
                <div className="relative aspect-[4/3] lg:aspect-auto overflow-hidden">
                  <ImageWithFallback
                    src={blogPosts[0].image}
                    alt={blogPosts[0].title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute top-4 left-4 px-3 py-1 bg-[var(--flame-orange)] rounded-full text-white text-sm flex items-center gap-1">
                    <TrendingUp className="w-4 h-4" />
                    Featured
                  </div>
                </div>
                <div className="p-8 flex flex-col justify-center">
                  <div className="inline-block px-3 py-1 bg-[var(--electric-blue)]/20 text-[var(--electric-blue)] rounded-full text-sm mb-4 self-start">
                    {blogPosts[0].category}
                  </div>
                  <h2 className="text-3xl text-white mb-4 group-hover:text-[var(--neon-cyan)] transition-colors">
                    {blogPosts[0].title}
                  </h2>
                  <p className="text-white/70 mb-6 leading-relaxed">
                    {blogPosts[0].excerpt}
                  </p>
                  <div className="flex items-center gap-4 text-sm text-white/60 mb-6">
                    <span className="flex items-center gap-1">
                      <User className="w-4 h-4" />
                      {blogPosts[0].author}
                    </span>
                    <span className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      {blogPosts[0].date}
                    </span>
                    <span>{blogPosts[0].readTime}</span>
                  </div>
                  <div className="flex items-center gap-2 text-[var(--neon-cyan)] group-hover:gap-3 transition-all">
                    Read More
                    <ArrowRight className="w-5 h-5" />
                  </div>
                </div>
              </div>
            </div>
          </Link>
        </motion.div>

        {/* Blog Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {blogPosts.slice(1).map((post, index) => (
            <motion.div
              key={post.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Link to={`/blog/${post.id}`} className="block group">
                <div className="rounded-2xl overflow-hidden bg-[var(--dark-card)] border border-white/10 hover:border-[var(--electric-blue)] transition-all hover:shadow-2xl hover:shadow-[var(--electric-blue)]/20">
                  <div className="relative aspect-video overflow-hidden">
                    <ImageWithFallback
                      src={post.image}
                      alt={post.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    {post.trending && (
                      <div className="absolute top-3 right-3 px-3 py-1 bg-[var(--flame-orange)] rounded-full text-white text-xs flex items-center gap-1">
                        <TrendingUp className="w-3 h-3" />
                        Trending
                      </div>
                    )}
                  </div>
                  <div className="p-6">
                    <div className="inline-block px-3 py-1 bg-white/5 text-white/70 rounded-full text-xs mb-3">
                      {post.category}
                    </div>
                    <h3 className="text-xl text-white mb-3 group-hover:text-[var(--neon-cyan)] transition-colors">
                      {post.title}
                    </h3>
                    <p className="text-white/70 text-sm mb-4 line-clamp-2">
                      {post.excerpt}
                    </p>
                    <div className="flex items-center gap-3 text-xs text-white/60">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {post.date}
                      </span>
                      <span>•</span>
                      <span>{post.readTime}</span>
                    </div>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
