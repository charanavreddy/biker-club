import { useState } from "react";
import { Link } from "react-router";
import { SlidersHorizontal, Grid3x3, List, MapPin } from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { Slider } from "../components/ui/slider";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { motion } from "motion/react";

const allBikes = [
  {
    id: 1,
    name: "Royal Enfield Classic 350",
    price: 185000,
    year: 2023,
    km: 8500,
    location: "Kochi",
    brand: "Royal Enfield",
    category: "Cruiser",
    image: "https://images.unsplash.com/photo-1663543454316-b5f8917b0278?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyb3lhbCUyMGVuZmllbGQlMjBjbGFzc2ljJTIwbW90b3JjeWNsZXxlbnwxfHx8fDE3NzE4Mzg3NzN8MA&ixlib=rb-4.1.0&q=80&w=1080",
    verified: true,
  },
  {
    id: 2,
    name: "Yamaha R15 V4",
    price: 145000,
    year: 2024,
    km: 3200,
    location: "Trivandrum",
    brand: "Yamaha",
    category: "Sport",
    image: "https://images.unsplash.com/photo-1709133650353-dcbabe8015ee?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5YW1haGElMjByMTUlMjBzcG9ydCUyMGJpa2V8ZW58MXx8fHwxNzcxODM4NzczfDA&ixlib=rb-4.1.0&q=80&w=1080",
    verified: true,
  },
  {
    id: 3,
    name: "KTM Duke 390",
    price: 220000,
    year: 2023,
    km: 5800,
    location: "Calicut",
    brand: "KTM",
    category: "Sport",
    image: "https://images.unsplash.com/photo-1670012300918-6e0dda76af1a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxrdG0lMjBkdWtlJTIwbW90b3JjeWNsZXxlbnwxfHx8fDE3NzE4MzQwNDJ8MA&ixlib=rb-4.1.0&q=80&w=1080",
    verified: true,
  },
  {
    id: 4,
    name: "Kawasaki Ninja 300",
    price: 285000,
    year: 2024,
    km: 2100,
    location: "Thrissur",
    brand: "Kawasaki",
    category: "Sport",
    image: "https://images.unsplash.com/photo-1736839659107-1befef3f3207?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxrYXdhc2FraSUyMG5pbmphJTIwc3BvcnQlMjBiaWtlfGVufDF8fHx8MTc3MTgyMDgyNnww&ixlib=rb-4.1.0&q=80&w=1080",
    verified: true,
  },
  {
    id: 5,
    name: "Honda CB350",
    price: 165000,
    year: 2023,
    km: 12000,
    location: "Kochi",
    brand: "Honda",
    category: "Cruiser",
    image: "https://images.unsplash.com/photo-1757776335616-ebdc7753fe91?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob25kYSUyMG1vdG9yY3ljbGUlMjBwYXJrZWR8ZW58MXx8fHwxNzcxODM4Nzc0fDA&ixlib=rb-4.1.0&q=80&w=1080",
    verified: false,
  },
  {
    id: 6,
    name: "Suzuki Gixxer SF",
    price: 95000,
    year: 2022,
    km: 15000,
    location: "Kannur",
    brand: "Suzuki",
    category: "Sport",
    image: "https://images.unsplash.com/photo-1599457641021-b5b3aca254ad?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdXp1a2klMjBnaXh4ZXIlMjBtb3RvcmN5Y2xlfGVufDF8fHx8MTc3MTgzODg0Mnww&ixlib=rb-4.1.0&q=80&w=1080",
    verified: true,
  },
  {
    id: 7,
    name: "Bajaj Pulsar NS200",
    price: 110000,
    year: 2023,
    km: 8000,
    location: "Palakkad",
    brand: "Bajaj",
    category: "Sport",
    image: "https://images.unsplash.com/photo-1594490165401-7c83be9f6b51?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYWphaiUyMHB1bHNhciUyMGJpa2V8ZW58MXx8fHwxNzcxODM4ODQzfDA&ixlib=rb-4.1.0&q=80&w=1080",
    verified: true,
  },
  {
    id: 8,
    name: "TVS Apache RTR 160",
    price: 85000,
    year: 2022,
    km: 18000,
    location: "Alappuzha",
    brand: "TVS",
    category: "Commuter",
    image: "https://images.unsplash.com/photo-1625641093465-52da8d2cc19d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0dnMlMjBhcGFjaGUlMjBtb3RvcmN5Y2xlfGVufDF8fHx8MTc3MTgzODg0NHww&ixlib=rb-4.1.0&q=80&w=1080",
    verified: false,
  },
];

export function Marketplace() {
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [priceRange, setPriceRange] = useState([0, 500000]);
  const [showFilters, setShowFilters] = useState(true);

  return (
    <div className="min-h-screen bg-[var(--midnight-black)] py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl mb-2">
            <span className="bg-gradient-to-r from-white to-white/80 bg-clip-text text-transparent">
              Marketplace
            </span>
          </h1>
          <p className="text-white/60">Browse {allBikes.length} available bikes</p>
        </div>

        {/* Filters & View Toggle */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
          <Button
            variant="outline"
            onClick={() => setShowFilters(!showFilters)}
            className="border-white/20 text-white hover:bg-white/10"
          >
            <SlidersHorizontal className="w-4 h-4 mr-2" />
            {showFilters ? "Hide" : "Show"} Filters
          </Button>

          <div className="flex items-center gap-2">
            <Select defaultValue="recent">
              <SelectTrigger className="w-[180px] bg-white/5 border-white/10 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-[var(--dark-card)] border-white/10">
                <SelectItem value="recent">Most Recent</SelectItem>
                <SelectItem value="price-low">Price: Low to High</SelectItem>
                <SelectItem value="price-high">Price: High to Low</SelectItem>
                <SelectItem value="km-low">KM: Low to High</SelectItem>
              </SelectContent>
            </Select>

            <div className="flex gap-1 ml-2">
              <Button
                size="icon"
                variant={viewMode === "grid" ? "default" : "ghost"}
                onClick={() => setViewMode("grid")}
                className={viewMode === "grid" ? "bg-[var(--electric-blue)]" : "text-white hover:bg-white/10"}
              >
                <Grid3x3 className="w-4 h-4" />
              </Button>
              <Button
                size="icon"
                variant={viewMode === "list" ? "default" : "ghost"}
                onClick={() => setViewMode("list")}
                className={viewMode === "list" ? "bg-[var(--electric-blue)]" : "text-white hover:bg-white/10"}
              >
                <List className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>

        <div className="flex gap-6">
          {/* Filters Sidebar */}
          {showFilters && (
            <motion.aside
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="w-64 shrink-0 hidden lg:block"
            >
              <div className="sticky top-24 space-y-6 p-6 rounded-2xl bg-[var(--dark-card)] border border-white/10">
                <div>
                  <h3 className="text-white mb-3">Brand</h3>
                  <Select>
                    <SelectTrigger className="bg-white/5 border-white/10 text-white">
                      <SelectValue placeholder="All Brands" />
                    </SelectTrigger>
                    <SelectContent className="bg-[var(--dark-card)] border-white/10">
                      <SelectItem value="all">All Brands</SelectItem>
                      <SelectItem value="royal-enfield">Royal Enfield</SelectItem>
                      <SelectItem value="yamaha">Yamaha</SelectItem>
                      <SelectItem value="ktm">KTM</SelectItem>
                      <SelectItem value="honda">Honda</SelectItem>
                      <SelectItem value="kawasaki">Kawasaki</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <h3 className="text-white mb-3">Category</h3>
                  <Select>
                    <SelectTrigger className="bg-white/5 border-white/10 text-white">
                      <SelectValue placeholder="All Categories" />
                    </SelectTrigger>
                    <SelectContent className="bg-[var(--dark-card)] border-white/10">
                      <SelectItem value="all">All Categories</SelectItem>
                      <SelectItem value="sport">Sport Bikes</SelectItem>
                      <SelectItem value="cruiser">Cruisers</SelectItem>
                      <SelectItem value="commuter">Commuters</SelectItem>
                      <SelectItem value="adventure">Adventure</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <h3 className="text-white mb-3">Location</h3>
                  <Select>
                    <SelectTrigger className="bg-white/5 border-white/10 text-white">
                      <SelectValue placeholder="All Locations" />
                    </SelectTrigger>
                    <SelectContent className="bg-[var(--dark-card)] border-white/10">
                      <SelectItem value="all">All Locations</SelectItem>
                      <SelectItem value="kochi">Kochi</SelectItem>
                      <SelectItem value="trivandrum">Trivandrum</SelectItem>
                      <SelectItem value="calicut">Calicut</SelectItem>
                      <SelectItem value="thrissur">Thrissur</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <h3 className="text-white mb-3">Price Range</h3>
                  <Slider
                    value={priceRange}
                    onValueChange={setPriceRange}
                    max={500000}
                    step={10000}
                    className="mb-2"
                  />
                  <div className="flex items-center justify-between text-sm text-white/60">
                    <span>₹{(priceRange[0] / 1000).toFixed(0)}k</span>
                    <span>₹{(priceRange[1] / 1000).toFixed(0)}k</span>
                  </div>
                </div>

                <div>
                  <h3 className="text-white mb-3">Year</h3>
                  <Select>
                    <SelectTrigger className="bg-white/5 border-white/10 text-white">
                      <SelectValue placeholder="All Years" />
                    </SelectTrigger>
                    <SelectContent className="bg-[var(--dark-card)] border-white/10">
                      <SelectItem value="all">All Years</SelectItem>
                      <SelectItem value="2024">2024</SelectItem>
                      <SelectItem value="2023">2023</SelectItem>
                      <SelectItem value="2022">2022</SelectItem>
                      <SelectItem value="2021">2021</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button className="w-full bg-gradient-to-r from-[var(--electric-blue)] to-[var(--neon-cyan)] hover:opacity-90">
                  Apply Filters
                </Button>
              </div>
            </motion.aside>
          )}

          {/* Listings */}
          <div className="flex-1">
            <div className={viewMode === "grid" ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" : "space-y-4"}>
              {allBikes.map((bike, index) => (
                <motion.div
                  key={bike.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <Link to={`/marketplace/${bike.id}`} className="block group">
                    <div className={`rounded-2xl overflow-hidden bg-[var(--dark-card)] border border-white/10 hover:border-[var(--electric-blue)] transition-all hover:shadow-2xl hover:shadow-[var(--electric-blue)]/20 ${viewMode === "list" ? "flex" : ""}`}>
                      <div className={`relative overflow-hidden ${viewMode === "list" ? "w-64" : "aspect-[4/3]"}`}>
                        <ImageWithFallback
                          src={bike.image}
                          alt={bike.name}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                        />
                        {bike.verified && (
                          <div className="absolute top-3 left-3 px-3 py-1 bg-[var(--lime-pulse)] text-[var(--midnight-black)] rounded-full text-xs">
                            ✓ Verified
                          </div>
                        )}
                      </div>
                      <div className="p-5 flex-1">
                        <h3 className="text-lg text-white mb-2 group-hover:text-[var(--neon-cyan)] transition-colors">
                          {bike.name}
                        </h3>
                        <div className="flex items-center gap-3 text-sm text-white/60 mb-3">
                          <span>{bike.year}</span>
                          <span>•</span>
                          <span>{bike.km.toLocaleString()} km</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-xl text-[var(--neon-cyan)]">
                            ₹{(bike.price / 1000).toFixed(0)}k
                          </span>
                          <div className="flex items-center gap-1 text-sm text-white/60">
                            <MapPin className="w-4 h-4" />
                            {bike.location}
                          </div>
                        </div>
                      </div>
                    </div>
                  </Link>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
