import { TrendingUp, Eye, Heart, MessageCircle, DollarSign, Package, Users } from "lucide-react";
import { Button } from "../components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { motion } from "motion/react";

const salesData = [
  { month: "Jan", sales: 4 },
  { month: "Feb", sales: 7 },
  { month: "Mar", sales: 5 },
  { month: "Apr", sales: 9 },
  { month: "May", sales: 12 },
  { month: "Jun", sales: 8 },
];

const viewsData = [
  { day: "Mon", views: 245 },
  { day: "Tue", views: 312 },
  { day: "Wed", views: 289 },
  { day: "Thu", views: 401 },
  { day: "Fri", views: 456 },
  { day: "Sat", views: 523 },
  { day: "Sun", views: 478 },
];

const activeListings = [
  { id: 1, name: "Royal Enfield Classic 350", views: 234, likes: 45, price: "₹1,85,000" },
  { id: 2, name: "Yamaha R15 V4", views: 189, likes: 32, price: "₹1,45,000" },
  { id: 3, name: "KTM Duke 390", views: 312, likes: 58, price: "₹2,20,000" },
];

export function Dashboard() {
  return (
    <div className="min-h-screen bg-[var(--midnight-black)] py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl mb-2">
            <span className="bg-gradient-to-r from-white to-white/80 bg-clip-text text-transparent">
              Seller Dashboard
            </span>
          </h1>
          <p className="text-white/60">Track your listings and performance</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Card className="bg-gradient-to-br from-[var(--electric-blue)]/20 to-[var(--neon-cyan)]/20 border-[var(--electric-blue)]/30">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm text-white/80">Total Sales</CardTitle>
                <DollarSign className="w-4 h-4 text-[var(--neon-cyan)]" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl text-white mb-1">45</div>
                <p className="text-xs text-white/60 flex items-center gap-1">
                  <TrendingUp className="w-3 h-3 text-[var(--lime-pulse)]" />
                  +12% from last month
                </p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <Card className="bg-gradient-to-br from-[var(--flame-orange)]/20 to-[var(--hot-pink)]/20 border-[var(--flame-orange)]/30">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm text-white/80">Active Listings</CardTitle>
                <Package className="w-4 h-4 text-[var(--flame-orange)]" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl text-white mb-1">3</div>
                <p className="text-xs text-white/60">2 featured listings</p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="bg-gradient-to-br from-[var(--lime-pulse)]/20 to-[var(--neon-cyan)]/20 border-[var(--lime-pulse)]/30">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm text-white/80">Total Views</CardTitle>
                <Eye className="w-4 h-4 text-[var(--lime-pulse)]" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl text-white mb-1">2,345</div>
                <p className="text-xs text-white/60 flex items-center gap-1">
                  <TrendingUp className="w-3 h-3 text-[var(--lime-pulse)]" />
                  +8% this week
                </p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="bg-gradient-to-br from-[var(--hot-pink)]/20 to-[var(--electric-blue)]/20 border-[var(--hot-pink)]/30">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm text-white/80">Messages</CardTitle>
                <MessageCircle className="w-4 h-4 text-[var(--hot-pink)]" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl text-white mb-1">18</div>
                <p className="text-xs text-white/60">5 unread messages</p>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Card className="bg-[var(--dark-card)] border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Sales Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart data={salesData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                    <XAxis dataKey="month" stroke="rgba(255,255,255,0.6)" />
                    <YAxis stroke="rgba(255,255,255,0.6)" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "var(--dark-surface)",
                        border: "1px solid rgba(255,255,255,0.1)",
                        borderRadius: "8px",
                        color: "white",
                      }}
                    />
                    <Bar dataKey="sales" fill="url(#colorSales)" radius={[8, 8, 0, 0]} />
                    <defs>
                      <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="var(--electric-blue)" />
                        <stop offset="100%" stopColor="var(--neon-cyan)" />
                      </linearGradient>
                    </defs>
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <Card className="bg-[var(--dark-card)] border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Views Analytics</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <LineChart data={viewsData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                    <XAxis dataKey="day" stroke="rgba(255,255,255,0.6)" />
                    <YAxis stroke="rgba(255,255,255,0.6)" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "var(--dark-surface)",
                        border: "1px solid rgba(255,255,255,0.1)",
                        borderRadius: "8px",
                        color: "white",
                      }}
                    />
                    <Line
                      type="monotone"
                      dataKey="views"
                      stroke="var(--neon-cyan)"
                      strokeWidth={3}
                      dot={{ fill: "var(--electric-blue)", strokeWidth: 2 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Active Listings */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <Card className="bg-[var(--dark-card)] border-white/10">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-white">Active Listings</CardTitle>
              <Button className="bg-gradient-to-r from-[var(--electric-blue)] to-[var(--neon-cyan)] hover:opacity-90">
                Add New Listing
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {activeListings.map((listing) => (
                  <div
                    key={listing.id}
                    className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/10 hover:border-[var(--electric-blue)]/50 transition-colors"
                  >
                    <div className="flex-1">
                      <h3 className="text-white mb-1">{listing.name}</h3>
                      <div className="flex items-center gap-4 text-sm text-white/60">
                        <span className="flex items-center gap-1">
                          <Eye className="w-4 h-4" />
                          {listing.views} views
                        </span>
                        <span className="flex items-center gap-1">
                          <Heart className="w-4 h-4" />
                          {listing.likes} likes
                        </span>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-[var(--neon-cyan)] mb-1">{listing.price}</div>
                      <Button variant="ghost" size="sm" className="text-white/60 hover:text-white hover:bg-white/10">
                        Edit
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
