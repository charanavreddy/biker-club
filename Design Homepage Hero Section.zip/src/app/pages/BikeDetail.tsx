import { useParams, Link } from "react-router";
import { ArrowLeft, MapPin, Calendar, Gauge, Fuel, Shield, Heart, Share2, MessageCircle, Phone } from "lucide-react";
import { Button } from "../components/ui/button";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { motion } from "motion/react";

export function BikeDetail() {
  const { id } = useParams();

  // Mock data - in real app, fetch based on id
  const bike = {
    id: 1,
    name: "Royal Enfield Classic 350",
    price: 185000,
    year: 2023,
    km: 8500,
    location: "Kochi, Kerala",
    brand: "Royal Enfield",
    category: "Cruiser",
    images: [
      "https://images.unsplash.com/photo-1663543454316-b5f8917b0278?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyb3lhbCUyMGVuZmllbGQlMjBjbGFzc2ljJTIwbW90b3JjeWNsZXxlbnwxfHx8fDE3NzE4Mzg3NzN8MA&ixlib=rb-4.1.0&q=80&w=1080",
    ],
    verified: true,
    seller: {
      name: "Rajesh Kumar",
      joined: "2 years ago",
      sales: 12,
      rating: 4.8,
    },
    specs: {
      engine: "349cc",
      power: "20.2 bhp",
      torque: "27 Nm",
      fuelType: "Petrol",
      transmission: "5-speed",
      owners: "1st Owner",
    },
    description: "Well-maintained Royal Enfield Classic 350 in excellent condition. Regular servicing done at authorized service center. All documents up to date. Single owner, accident-free bike. Reason for sale: Upgrading to a bigger bike.",
  };

  return (
    <div className="min-h-screen bg-[var(--midnight-black)] py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Button */}
        <Link to="/marketplace" className="inline-flex items-center gap-2 text-white/70 hover:text-[var(--neon-cyan)] transition-colors mb-6">
          <ArrowLeft className="w-5 h-5" />
          Back to Marketplace
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Image Gallery */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="rounded-2xl overflow-hidden bg-[var(--dark-card)] border border-white/10"
            >
              <div className="aspect-video relative">
                <ImageWithFallback
                  src={bike.images[0]}
                  alt={bike.name}
                  className="w-full h-full object-cover"
                />
                {bike.verified && (
                  <div className="absolute top-4 left-4 px-4 py-2 bg-[var(--lime-pulse)] text-[var(--midnight-black)] rounded-full flex items-center gap-2">
                    <Shield className="w-4 h-4" />
                    Verified Seller
                  </div>
                )}
                <div className="absolute top-4 right-4 flex gap-2">
                  <button className="w-10 h-10 rounded-full bg-white/10 backdrop-blur-md hover:bg-white/20 flex items-center justify-center transition-colors">
                    <Heart className="w-5 h-5 text-white" />
                  </button>
                  <button className="w-10 h-10 rounded-full bg-white/10 backdrop-blur-md hover:bg-white/20 flex items-center justify-center transition-colors">
                    <Share2 className="w-5 h-5 text-white" />
                  </button>
                </div>
              </div>
            </motion.div>

            {/* Details */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="rounded-2xl p-6 bg-[var(--dark-card)] border border-white/10"
            >
              <h1 className="text-3xl text-white mb-2">{bike.name}</h1>
              <div className="flex items-center gap-4 text-white/60 mb-6">
                <span className="flex items-center gap-1">
                  <MapPin className="w-4 h-4" />
                  {bike.location}
                </span>
                <span>•</span>
                <span>{bike.category}</span>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                  <Calendar className="w-5 h-5 text-[var(--neon-cyan)] mb-2" />
                  <div className="text-sm text-white/60">Year</div>
                  <div className="text-white">{bike.year}</div>
                </div>
                <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                  <Gauge className="w-5 h-5 text-[var(--neon-cyan)] mb-2" />
                  <div className="text-sm text-white/60">Kilometers</div>
                  <div className="text-white">{bike.km.toLocaleString()}</div>
                </div>
                <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                  <Fuel className="w-5 h-5 text-[var(--neon-cyan)] mb-2" />
                  <div className="text-sm text-white/60">Fuel Type</div>
                  <div className="text-white">{bike.specs.fuelType}</div>
                </div>
                <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                  <Shield className="w-5 h-5 text-[var(--neon-cyan)] mb-2" />
                  <div className="text-sm text-white/60">Owner</div>
                  <div className="text-white">{bike.specs.owners}</div>
                </div>
              </div>

              <div className="border-t border-white/10 pt-6">
                <h2 className="text-xl text-white mb-4">Description</h2>
                <p className="text-white/70 leading-relaxed">{bike.description}</p>
              </div>
            </motion.div>

            {/* Specifications */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="rounded-2xl p-6 bg-[var(--dark-card)] border border-white/10"
            >
              <h2 className="text-xl text-white mb-4">Specifications</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {Object.entries(bike.specs).map(([key, value]) => (
                  <div key={key} className="flex items-center justify-between p-3 rounded-lg bg-white/5">
                    <span className="text-white/60 capitalize">{key.replace(/([A-Z])/g, " $1")}</span>
                    <span className="text-white">{value}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Price Card */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="sticky top-24 rounded-2xl p-6 bg-gradient-to-br from-[var(--dark-card)] to-[var(--dark-surface)] border border-white/10"
            >
              <div className="text-4xl mb-6">
                <span className="bg-gradient-to-r from-[var(--electric-blue)] to-[var(--neon-cyan)] bg-clip-text text-transparent">
                  ₹{(bike.price / 1000).toFixed(0)}k
                </span>
              </div>

              <div className="space-y-3 mb-6">
                <Button className="w-full bg-gradient-to-r from-[var(--electric-blue)] to-[var(--neon-cyan)] hover:opacity-90 shadow-lg shadow-[var(--electric-blue)]/30">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Chat with Seller
                </Button>
                <Button variant="outline" className="w-full border-white/20 text-white hover:bg-white/10">
                  <Phone className="w-4 h-4 mr-2" />
                  Call Seller
                </Button>
              </div>

              <div className="border-t border-white/10 pt-6">
                <h3 className="text-white mb-4">Seller Information</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-white/60">Name</span>
                    <span className="text-white">{bike.seller.name}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-white/60">Member since</span>
                    <span className="text-white">{bike.seller.joined}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-white/60">Bikes sold</span>
                    <span className="text-white">{bike.seller.sales}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-white/60">Rating</span>
                    <span className="text-[var(--lime-pulse)]">★ {bike.seller.rating}</span>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Safety Tips */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
              className="rounded-2xl p-6 bg-[var(--dark-card)] border border-white/10"
            >
              <h3 className="text-white mb-4 flex items-center gap-2">
                <Shield className="w-5 h-5 text-[var(--flame-orange)]" />
                Safety Tips
              </h3>
              <ul className="space-y-2 text-sm text-white/70">
                <li>• Always meet in a safe public location</li>
                <li>• Verify all documents before payment</li>
                <li>• Test ride the bike thoroughly</li>
                <li>• Check for any outstanding loans</li>
                <li>• Use secure payment methods</li>
              </ul>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
