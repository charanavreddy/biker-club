import { createBrowserRouter } from "react-router";
import { Layout } from "./components/Layout";
import { Home } from "./pages/Home";
import { Marketplace } from "./pages/Marketplace";
import { BikeDetail } from "./pages/BikeDetail";
import { Community } from "./pages/Community";
import { Dashboard } from "./pages/Dashboard";
import { Blog } from "./pages/Blog";
import { BlogPost } from "./pages/BlogPost";
import { PriceEstimator } from "./pages/PriceEstimator";
import { SellBike } from "./pages/SellBike";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: Home },
      { path: "marketplace", Component: Marketplace },
      { path: "marketplace/:id", Component: BikeDetail },
      { path: "community", Component: Community },
      { path: "dashboard", Component: Dashboard },
      { path: "blog", Component: Blog },
      { path: "blog/:id", Component: BlogPost },
      { path: "price-estimator", Component: PriceEstimator },
      { path: "sell", Component: SellBike },
    ],
  },
]);
