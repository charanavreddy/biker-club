import { MessageCircle, X, Send } from "lucide-react";
import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";

export function ChatWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState("");

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {!isOpen ? (
        <button
          onClick={() => setIsOpen(true)}
          className="w-14 h-14 rounded-full bg-gradient-to-r from-[var(--electric-blue)] to-[var(--neon-cyan)] shadow-2xl shadow-[var(--electric-blue)]/40 hover:shadow-[var(--electric-blue)]/60 flex items-center justify-center transition-all hover:scale-110"
        >
          <MessageCircle className="w-6 h-6 text-white" />
        </button>
      ) : (
        <div className="w-80 h-96 rounded-2xl bg-[var(--dark-card)] border border-white/10 shadow-2xl flex flex-col overflow-hidden backdrop-blur-xl">
          {/* Header */}
          <div className="bg-gradient-to-r from-[var(--electric-blue)] to-[var(--neon-cyan)] p-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <MessageCircle className="w-5 h-5 text-white" />
              <span className="text-white">Support Chat</span>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-white/80 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3">
            <div className="bg-white/5 rounded-lg p-3 max-w-[80%]">
              <p className="text-white/90 text-sm">
                Hi! How can we help you today?
              </p>
              <span className="text-white/40 text-xs">Support Team</span>
            </div>
          </div>

          {/* Input */}
          <div className="p-4 border-t border-white/10">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                setMessage("");
              }}
              className="flex gap-2"
            >
              <Input
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Type your message..."
                className="flex-1 bg-white/5 border-white/10 text-white placeholder:text-white/40"
              />
              <Button
                type="submit"
                size="icon"
                className="bg-[var(--electric-blue)] hover:bg-[var(--neon-cyan)] shrink-0"
              >
                <Send className="w-4 h-4" />
              </Button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
