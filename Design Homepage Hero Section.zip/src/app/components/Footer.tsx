import { Link } from "react-router";
import { Facebook, Instagram, Twitter, Linkedin, Zap, Mail, Phone, MapPin } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-[var(--dark-surface)] border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Zap className="w-6 h-6 fill-[var(--electric-blue)] text-[var(--electric-blue)]" />
              <span className="text-lg">
                <span className="bg-gradient-to-r from-[var(--electric-blue)] to-[var(--neon-cyan)] bg-clip-text text-transparent">AZ</span>
                <span className="text-white ml-1">Bikerala</span>
              </span>
            </div>
            <p className="text-white/60 mb-4">
              The complete motorcycle marketplace & community platform.
            </p>
            <div className="flex gap-3">
              <SocialLink href="https://facebook.com" icon={Facebook} />
              <SocialLink href="https://instagram.com" icon={Instagram} />
              <SocialLink href="https://twitter.com" icon={Twitter} />
              <SocialLink href="https://linkedin.com" icon={Linkedin} />
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <FooterLink to="/marketplace">Browse Bikes</FooterLink>
              <FooterLink to="/sell">Sell Your Bike</FooterLink>
              <FooterLink to="/price-estimator">AI Price Estimator</FooterLink>
              <FooterLink to="/community">Community</FooterLink>
              <FooterLink to="/blog">Blog</FooterLink>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="text-white mb-4">Support</h3>
            <ul className="space-y-2">
              <FooterLink to="/help">Help Center</FooterLink>
              <FooterLink to="/safety">Safety Tips</FooterLink>
              <FooterLink to="/terms">Terms of Service</FooterLink>
              <FooterLink to="/privacy">Privacy Policy</FooterLink>
              <FooterLink to="/contact">Contact Us</FooterLink>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-white mb-4">Contact</h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-2 text-white/60">
                <Mail className="w-5 h-5 mt-0.5 text-[var(--neon-cyan)]" />
                <span>support@azbikerala.com</span>
              </li>
              <li className="flex items-start gap-2 text-white/60">
                <Phone className="w-5 h-5 mt-0.5 text-[var(--neon-cyan)]" />
                <span>+91 1234 567 890</span>
              </li>
              <li className="flex items-start gap-2 text-white/60">
                <MapPin className="w-5 h-5 mt-0.5 text-[var(--neon-cyan)]" />
                <span>Kochi, Kerala, India</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-white/10">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-white/60 text-sm">
              © 2026 AZ Bikerala. All rights reserved.
            </p>
            <div className="flex gap-6 text-sm">
              <Link to="/terms" className="text-white/60 hover:text-[var(--neon-cyan)] transition-colors">
                Terms
              </Link>
              <Link to="/privacy" className="text-white/60 hover:text-[var(--neon-cyan)] transition-colors">
                Privacy
              </Link>
              <Link to="/cookies" className="text-white/60 hover:text-[var(--neon-cyan)] transition-colors">
                Cookies
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}

function SocialLink({ href, icon: Icon }: { href: string; icon: any }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="w-10 h-10 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center text-white/60 hover:text-[var(--neon-cyan)] transition-all border border-white/10 hover:border-[var(--neon-cyan)] hover:shadow-lg hover:shadow-[var(--neon-cyan)]/20"
    >
      <Icon className="w-5 h-5" />
    </a>
  );
}

function FooterLink({ to, children }: { to: string; children: React.ReactNode }) {
  return (
    <li>
      <Link to={to} className="text-white/60 hover:text-[var(--neon-cyan)] transition-colors">
        {children}
      </Link>
    </li>
  );
}
