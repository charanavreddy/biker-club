import { Link } from "react-router";
import { Menu, X, Zap, ShoppingBag, Users, LayoutDashboard, BookOpen, Calculator, Plus } from "lucide-react";
import { useState } from "react";
import { Button } from "./ui/button";

export function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <nav className="sticky top-0 z-50 backdrop-blur-xl bg-[var(--midnight-black)]/80 border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 group">
            <div className="relative">
              <Zap className="w-8 h-8 fill-[var(--electric-blue)] text-[var(--electric-blue)] group-hover:fill-[var(--neon-cyan)] group-hover:text-[var(--neon-cyan)] transition-colors" />
              <div className="absolute inset-0 blur-xl bg-[var(--electric-blue)] opacity-50 group-hover:opacity-75 transition-opacity" />
            </div>
            <div>
              <span className="text-xl tracking-tight">
                <span className="bg-gradient-to-r from-[var(--electric-blue)] to-[var(--neon-cyan)] bg-clip-text text-transparent">AZ</span>
                <span className="text-white ml-1">Bikerala</span>
              </span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-6">
            <NavLink to="/marketplace" icon={ShoppingBag}>Marketplace</NavLink>
            <NavLink to="/community" icon={Users}>Community</NavLink>
            <NavLink to="/blog" icon={BookOpen}>Blog</NavLink>
            <NavLink to="/price-estimator" icon={Calculator}>Price AI</NavLink>
            <NavLink to="/dashboard" icon={LayoutDashboard}>Dashboard</NavLink>
          </div>

          {/* CTA Buttons */}
          <div className="hidden md:flex items-center gap-3">
            <Link to="/sell">
              <Button className="bg-gradient-to-r from-[var(--electric-blue)] to-[var(--neon-cyan)] hover:opacity-90 transition-opacity shadow-lg shadow-[var(--electric-blue)]/30">
                <Plus className="w-4 h-4 mr-1" />
                Sell Bike
              </Button>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-white hover:bg-white/10 rounded-lg transition-colors"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-white/10 bg-[var(--dark-surface)]">
          <div className="px-4 py-4 space-y-2">
            <MobileNavLink to="/marketplace" icon={ShoppingBag}>Marketplace</MobileNavLink>
            <MobileNavLink to="/community" icon={Users}>Community</MobileNavLink>
            <MobileNavLink to="/blog" icon={BookOpen}>Blog</MobileNavLink>
            <MobileNavLink to="/price-estimator" icon={Calculator}>Price AI</MobileNavLink>
            <MobileNavLink to="/dashboard" icon={LayoutDashboard}>Dashboard</MobileNavLink>
            <Link to="/sell" className="block mt-4">
              <Button className="w-full bg-gradient-to-r from-[var(--electric-blue)] to-[var(--neon-cyan)] hover:opacity-90 transition-opacity">
                <Plus className="w-4 h-4 mr-1" />
                Sell Bike
              </Button>
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
}

function NavLink({ to, icon: Icon, children }: { to: string; icon: any; children: React.ReactNode }) {
  return (
    <Link
      to={to}
      className="flex items-center gap-2 text-white/70 hover:text-[var(--neon-cyan)] transition-colors group"
    >
      <Icon className="w-4 h-4 group-hover:text-[var(--neon-cyan)]" />
      {children}
    </Link>
  );
}

function MobileNavLink({ to, icon: Icon, children }: { to: string; icon: any; children: React.ReactNode }) {
  return (
    <Link
      to={to}
      className="flex items-center gap-3 p-3 text-white/70 hover:text-white hover:bg-white/5 rounded-lg transition-colors"
    >
      <Icon className="w-5 h-5" />
      {children}
    </Link>
  );
}
