
  # Design Homepage Hero Section

  This is a code bundle for Design Homepage Hero Section. The original project is available at https://www.figma.com/design/JK3H7MD0EHrvOiwJH6YHIH/Design-Homepage-Hero-Section.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  